// app/petugas/sisa-lapak/page.tsx
"use client";

import { useEffect, useMemo, useState } from "react";
import { MapPin, Store, PackageCheck, PackageX, Loader2 } from "lucide-react";

// Bentuk response yang diharapkan dari GET /api/petugas/sisa-lapak.
// Backend tinggal balikin array kecamatan, masing-masing berisi daftar
// jalan {nama, kuota, terisi} -- nggak perlu hitung "sisa" di backend,
// itu dihitung di frontend (kuota - terisi).
type JalanData = {
  nama: string;
  kuota: number;
  terisi: number;
};

type KecamatanData = {
  kecamatan: string;
  jalan: JalanData[];
};

function apiUrl(path: string) {
  const base = process.env.NEXT_PUBLIC_API_URL;
  if (!base) {
    throw new Error("NEXT_PUBLIC_API_URL belum diset di .env.local!");
  }
  return `${base}${path}`;
}

async function apiFetch(path: string, options: RequestInit = {}) {
  const token = localStorage.getItem("cfd_token");
  if (!token) {
    throw new Error("belum login");
  }

  const res = await fetch(apiUrl(path), {
    ...options,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
      ...(options.headers ?? {}),
    },
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || `request gagal (status ${res.status})`);
  }
  return data;
}

function levelSisa(sisa: number, kuota: number) {
  const rasio = kuota > 0 ? sisa / kuota : 0;
  if (rasio <= 0) {
    return { label: "Penuh", bg: "bg-error-container/60", text: "text-on-error-container", bar: "bg-error" };
  }
  if (rasio <= 0.2) {
    return { label: "Hampir Penuh", bg: "bg-tertiary-container/25", text: "text-on-tertiary-container", bar: "bg-tertiary" };
  }
  return { label: "Tersedia", bg: "bg-secondary-container/40", text: "text-on-secondary-container", bar: "bg-secondary" };
}

export default function SisaLapakPage() {
  const [data, setData] = useState<KecamatanData[] | null>(null);
  const [isLoadingPage, setIsLoadingPage] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [activeKecamatan, setActiveKecamatan] = useState<string | null>(null);

  const loadSisaLapak = async () => {
    try {
      const res = (await apiFetch("/api/petugas/sisa-lapak")) as KecamatanData[];
      setData(res);
      setLoadError(null);
      // set tab aktif ke kecamatan pertama, tapi cuma sekali pas data awal masuk
      setActiveKecamatan((prev) => prev ?? res[0]?.kecamatan ?? null);
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : "gagal memuat data sisa lapak");
    } finally {
      setIsLoadingPage(false);
    }
  };

  useEffect(() => {
    loadSisaLapak();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const totalRingkasan = useMemo(() => {
    let kuota = 0;
    let terisi = 0;
    for (const k of data ?? []) {
      for (const j of k.jalan) {
        kuota += j.kuota;
        terisi += j.terisi;
      }
    }
    return { kuota, terisi, sisa: kuota - terisi };
  }, [data]);

  if (isLoadingPage) {
    return (
      <div className="flex items-center justify-center py-24 text-on-surface-variant">
        <Loader2 className="h-6 w-6 animate-spin" strokeWidth={2} />
      </div>
    );
  }

  if (loadError || !data) {
    return (
      <div className="rounded-lg border border-error-container bg-error-container/20 p-lg text-on-error-container">
        Gagal memuat data sisa lapak: {loadError ?? "data tidak ditemukan"}
      </div>
    );
  }

  const dataAktif = data.find((k) => k.kecamatan === activeKecamatan) ?? data[0];

  return (
    <div className="flex flex-col gap-lg">
      {/* Header */}
      <div>
        <h2 className="text-headline-lg text-on-surface">Sisa Lapak</h2>
        <p className="mt-xs max-w-2xl text-body-md text-on-surface-variant">
          Lihat sisa lapak yang masih tersedia di setiap kecamatan dan jalan CFD Surabaya.
        </p>
      </div>

      {data.length === 0 ? (
        <div className="rounded-xl border border-outline-variant bg-surface-container-lowest p-lg text-center text-body-md text-on-surface-variant">
          Belum ada data kuota lapak yang diatur.
        </div>
      ) : (
        <>
          {/* Ringkasan total */}
          <div className="grid grid-cols-1 gap-md sm:grid-cols-3">
            <div className="rounded-xl border border-outline-variant bg-surface-container-lowest p-lg">
              <div className="flex items-center justify-between">
                <span className="text-label-sm text-on-surface-variant">Total Kuota Lapak</span>
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
                  <Store className="h-4 w-4 text-primary" strokeWidth={2} />
                </span>
              </div>
              <p className="mt-xs text-title-lg font-semibold text-on-surface">{totalRingkasan.kuota}</p>
            </div>
            <div className="rounded-xl border border-outline-variant bg-surface-container-lowest p-lg">
              <div className="flex items-center justify-between">
                <span className="text-label-sm text-on-surface-variant">Sudah Terisi</span>
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-secondary-container/30">
                  <PackageCheck className="h-4 w-4 text-secondary" strokeWidth={2} />
                </span>
              </div>
              <p className="mt-xs text-title-lg font-semibold text-on-surface">{totalRingkasan.terisi}</p>
            </div>
            <div className="rounded-xl border border-outline-variant bg-surface-container-lowest p-lg">
              <div className="flex items-center justify-between">
                <span className="text-label-sm text-on-surface-variant">Sisa Lapak</span>
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-tertiary-container/25">
                  <PackageX className="h-4 w-4 text-tertiary" strokeWidth={2} />
                </span>
              </div>
              <p className="mt-xs text-title-lg font-semibold text-on-surface">{totalRingkasan.sisa}</p>
            </div>
          </div>

          {/* Tab kecamatan */}
          <div className="flex flex-wrap gap-xs rounded-xl border border-outline-variant bg-surface-container-lowest p-1">
            {data.map((k) => (
              <button
                key={k.kecamatan}
                type="button"
                onClick={() => setActiveKecamatan(k.kecamatan)}
                className={`flex items-center gap-xs rounded-lg px-md py-sm text-label-md transition-all ${
                  activeKecamatan === k.kecamatan
                    ? "bg-primary text-on-primary shadow-sm"
                    : "text-on-surface-variant hover:bg-surface-container-high"
                }`}
              >
                <MapPin className="h-4 w-4" strokeWidth={2} />
                {k.kecamatan}
              </button>
            ))}
          </div>

          {/* Daftar jalan di kecamatan aktif */}
          <div className="grid grid-cols-1 gap-md sm:grid-cols-2">
            {dataAktif?.jalan.map((j) => {
              const sisa = j.kuota - j.terisi;
              const level = levelSisa(sisa, j.kuota);
              const persentase = j.kuota > 0 ? Math.min(100, Math.round((j.terisi / j.kuota) * 100)) : 0;

              return (
                <div
                  key={j.nama}
                  className="rounded-xl border border-outline-variant bg-surface-container-lowest p-lg transition-shadow hover:shadow-md"
                >
                  <div className="flex flex-wrap items-center justify-between gap-sm">
                    <h3 className="text-title-md text-on-surface">{j.nama}</h3>
                    <span className={`inline-flex items-center gap-xs rounded-full px-sm py-1 text-label-sm ${level.bg} ${level.text}`}>
                      {level.label}
                    </span>
                  </div>

                  <div className="mt-md flex items-baseline gap-xs">
                    <span className="text-title-lg font-semibold text-on-surface">{sisa}</span>
                    <span className="text-label-sm text-on-surface-variant">sisa dari {j.kuota} lapak</span>
                  </div>

                  <div className="mt-sm h-2 w-full overflow-hidden rounded-full bg-surface-container-high">
                    <div className={`h-full rounded-full ${level.bar} transition-all duration-500`} style={{ width: `${persentase}%` }} />
                  </div>
                  <p className="mt-xs text-label-sm text-on-surface-variant">
                    {j.terisi} terisi &middot; {persentase}% dari kuota
                  </p>
                </div>
              );
            })}

            {dataAktif?.jalan.length === 0 && (
              <p className="col-span-full py-md text-center text-body-md text-on-surface-variant">
                Belum ada data jalan untuk kecamatan ini.
              </p>
            )}
          </div>
        </>
      )}
    </div>
  );
}
