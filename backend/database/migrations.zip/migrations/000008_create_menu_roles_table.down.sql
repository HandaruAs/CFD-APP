DROP TABLE IF EXISTS menu_roles;
