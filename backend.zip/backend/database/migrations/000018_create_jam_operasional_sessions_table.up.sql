-- Tipe status buat satu sesi CFD dalam sehari.
-- belum_dimulai -> sudah dijadwalkan tapi petugas belum klik "Mulai Sesi"
-- berlangsung    -> sudah dibuka, belum ditutup
-- selesai        -> sudah ditutup
CREATE TYPE sesi_operasional_status AS ENUM ('belum_dimulai', 'berlangsung', 'selesai');

CREATE TABLE jam_operasional_sessions (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tanggal             DATE NOT NULL,

    -- jam rencana: yang diatur/diedit petugas sebelum sesi dimulai
    jam_mulai_rencana   TIME NOT NULL,
    jam_selesai_rencana TIME NOT NULL,

    -- jam aktual: diisi sistem otomatis pas petugas beneran klik mulai/tutup.
    -- NULL selama status masih 'belum_dimulai' atau 'berlangsung' (untuk kolom selesai).
    jam_mulai_aktual    TIMESTAMPTZ,
    jam_selesai_aktual  TIMESTAMPTZ,

    status              sesi_operasional_status NOT NULL DEFAULT 'belum_dimulai',

    dibuka_oleh         UUID REFERENCES users(id) ON DELETE SET NULL,
    ditutup_oleh        UUID REFERENCES users(id) ON DELETE SET NULL,

    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Satu hari cuma boleh ada satu sesi.
CREATE UNIQUE INDEX idx_jam_operasional_tanggal ON jam_operasional_sessions (tanggal);
CREATE INDEX idx_jam_operasional_status ON jam_operasional_sessions (status);
