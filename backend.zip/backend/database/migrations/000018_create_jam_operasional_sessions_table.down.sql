DROP TABLE IF EXISTS jam_operasional_sessions;
DROP TYPE IF EXISTS sesi_operasional_status;
