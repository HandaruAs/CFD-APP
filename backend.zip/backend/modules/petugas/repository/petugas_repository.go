// modules/petugas/repository/petugas_repository.go

package repository

import (
	"context"
	"errors"
	"fmt"
	"time"

	"cfd-backend/modules/petugas/entity"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

type PetugasRepository struct {
	db *pgxpool.Pool
}

func NewPetugasRepository(db *pgxpool.Pool) *PetugasRepository {
	return &PetugasRepository{db: db}
}

// ==================== DASHBOARD ====================

func (r *PetugasRepository) GetDashboard(ctx context.Context) (*entity.DashboardResponse, error) {
	return &entity.DashboardResponse{
		StatusArea:   "Aktif",
		JamMulai:     "06:00",
		JamSelesai:   "11:00",
		TotalLapak:   300,
		LapakTerisi:  248,
		PersenTerisi: 82.7,
		PetugasAktif: 12,
		KehadiranTerbaru: []entity.KehadiranItem{
			{KodeLapak: "A12", Nama: "Warung Nasi Uduk", Kategori: "Makanan Berat", Waktu: "06:15"},
			{KodeLapak: "B05", Nama: "Es Jeruk Peras", Kategori: "Minuman", Waktu: "06:30"},
			{KodeLapak: "C42", Nama: "Dimsum Rakyat 99", Kategori: "Camilan", Waktu: "06:42"},
			{KodeLapak: "A08", Nama: "Sate Padang", Kategori: "Makanan Berat", Waktu: "07:05"},
			{KodeLapak: "D15", Nama: "Kopi Keliling", Kategori: "Minuman", Waktu: "07:12"},
		},
	}, nil
}

// ==================== DATA PEDAGANG ====================

func (r *PetugasRepository) GetListPedagang(ctx context.Context, page, limit int, search, kategori, zona string) (*entity.ListPedagangResponse, error) {
	total := 150
	totalPages := (total + limit - 1) / limit

	data := []entity.DataPedagangResponse{
		{ID: "APDC-001", NamaUsaha: "Sate Madura Cak Budi", Pemilik: "Budi Santosa", Inisial: "SB", Kategori: "kuliner", LokasiLapak: "Blok A1 - Zona Timur", StatusKehadiran: "hadir"},
		{ID: "APDC-042", NamaUsaha: "Batik Aminah", Pemilik: "Siti Aminah", Inisial: "SA", Kategori: "kerajinan", LokasiLapak: "Blok C3 - Zona Tengah", StatusKehadiran: "hadir"},
		{ID: "APDC-115", NamaUsaha: "Mainan Anak Wira", Pemilik: "Agus Wibowo", Inisial: "AW", Kategori: "ritel", LokasiLapak: "Blok D1 - Zona Barat", StatusKehadiran: "absen"},
		{ID: "APDC-088", NamaUsaha: "Es Jeruk Peras Segar", Pemilik: "Joko Riyadi", Inisial: "JR", Kategori: "kuliner", LokasiLapak: "Blok A5 - Zona Timur", StatusKehadiran: "hadir"},
	}

	return &entity.ListPedagangResponse{
		Data:       data,
		Total:      total,
		Page:       page,
		Limit:      limit,
		TotalPages: totalPages,
	}, nil
}

// ==================== MANAJEMEN LAPAK ====================

func (r *PetugasRepository) GetManajemenLapak(ctx context.Context) (*entity.ManajemenLapakResponse, error) {
	zona := []entity.ZonaLapak{
		{
			Nama:  "Zona A",
			Label: "Utara",
			Lapak: []entity.LapakItem{
				{Kode: "A-01", Status: "terisi", Pedagang: ptr("Budi Kopi")},
				{Kode: "A-02", Status: "terisi", Pedagang: ptr("Soto Ayam")},
				{Kode: "A-03", Status: "kosong"},
				{Kode: "A-04", Status: "terisi", Pedagang: ptr("Es Teh Manis")},
				{Kode: "A-05", Status: "terisi", Pedagang: ptr("Pecel Lele")},
			},
		},
		{
			Nama:  "Zona B",
			Label: "Tengah",
			Lapak: []entity.LapakItem{
				{Kode: "B-01", Status: "kosong"},
				{Kode: "B-02", Status: "kosong"},
				{Kode: "B-03", Status: "terisi", Pedagang: ptr("Gorengan")},
			},
		},
	}

	return &entity.ManajemenLapakResponse{
		TotalLapak:    300,
		LapakTerisi:   248,
		LapakTersedia: 52,
		Zona:          zona,
	}, nil
}

func ptr(s string) *string {
	return &s
}

// ==================== JAM OPERASIONAL ====================

var hariID = []string{"Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"}
var bulanID = []string{"", "Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"}

func formatTanggalID(tanggal string) string {
	t, err := time.Parse("2006-01-02", tanggal)
	if err != nil {
		return tanggal
	}
	return fmt.Sprintf("%s, %02d %s %d", hariID[t.Weekday()], t.Day(), bulanID[t.Month()], t.Year())
}

func toMenit(jam string) int {
	var h, m int
	fmt.Sscanf(jam, "%d:%d", &h, &m)
	return h*60 + m
}

type sesiRow struct {
	ID                string
	Tanggal           string
	JamMulaiRencana   string
	JamSelesaiRencana string
	JamMulaiAktual    *time.Time
	JamSelesaiAktual  *time.Time
	Status            string
}

const sesiColumns = `id,
	to_char(tanggal, 'YYYY-MM-DD'),
	to_char(jam_mulai_rencana, 'HH24:MI'),
	to_char(jam_selesai_rencana, 'HH24:MI'),
	jam_mulai_aktual,
	jam_selesai_aktual,
	status::text`

func scanSesi(row pgx.Row) (*sesiRow, error) {
	var s sesiRow
	err := row.Scan(&s.ID, &s.Tanggal, &s.JamMulaiRencana, &s.JamSelesaiRencana, &s.JamMulaiAktual, &s.JamSelesaiAktual, &s.Status)
	if err != nil {
		return nil, err
	}
	return &s, nil
}

// Cek apakah masih bisa edit di hari yang sama (sebelum 23:59)
func (r *PetugasRepository) canEditToday(ctx context.Context) bool {
	var now time.Time
	err := r.db.QueryRow(ctx, `SELECT NOW()`).Scan(&now)
	if err != nil {
		return false
	}

	// Kalau sudah lewat jam 23:59, tidak bisa edit
	if now.Hour() >= 23 && now.Minute() >= 59 {
		return false
	}
	return true
}

// getOrCreateSesiHariIni ambil sesi hari ini; kalau belum ada baris
// buat tanggal hari ini, otomatis dibikinin satu dengan jam rencana
// default 06:00-11:00, status belum_dimulai.
func (r *PetugasRepository) getOrCreateSesiHariIni(ctx context.Context) (*sesiRow, error) {
	return scanSesi(r.db.QueryRow(ctx,
		`INSERT INTO jam_operasional_sessions (tanggal, jam_mulai_rencana, jam_selesai_rencana)
		 VALUES (CURRENT_DATE, '06:00', '11:00')
		 ON CONFLICT (tanggal) DO UPDATE SET tanggal = EXCLUDED.tanggal
		 RETURNING `+sesiColumns))
}

func buildStatusSesi(s *sesiRow) entity.StatusSesiResponse {
	jamMulai := s.JamMulaiRencana
	if s.JamMulaiAktual != nil {
		jamMulai = s.JamMulaiAktual.Local().Format("15:04")
	}
	jamSelesai := s.JamSelesaiRencana
	if s.JamSelesaiAktual != nil {
		jamSelesai = s.JamSelesaiAktual.Local().Format("15:04")
	}

	totalMenit := toMenit(s.JamSelesaiRencana) - toMenit(s.JamMulaiRencana)
	if totalMenit < 0 {
		totalMenit = 0
	}

	sisaMenit := totalMenit
	switch s.Status {
	case "berlangsung":
		now := time.Now()
		nowMenit := now.Hour()*60 + now.Minute()
		sisaMenit = toMenit(s.JamSelesaiRencana) - nowMenit
		if sisaMenit < 0 {
			sisaMenit = 0
		}
	case "selesai":
		sisaMenit = 0
	}

	return entity.StatusSesiResponse{
		Status:     s.Status,
		JamMulai:   jamMulai,
		JamSelesai: jamSelesai,
		SisaWaktu:  fmt.Sprintf("%02d:%02d", sisaMenit/60, sisaMenit%60),
		TotalMenit: totalMenit,
		SisaMenit:  sisaMenit,
	}
}

func (r *PetugasRepository) getRiwayatOperasional(ctx context.Context, limit int) ([]entity.RiwayatOperasional, error) {
	rows, err := r.db.Query(ctx, `
		SELECT to_char(tanggal, 'YYYY-MM-DD'),
			to_char(jam_mulai_rencana, 'HH24:MI'),
			to_char(jam_selesai_rencana, 'HH24:MI'),
			jam_mulai_aktual, jam_selesai_aktual
		FROM jam_operasional_sessions
		WHERE status = 'selesai'
		ORDER BY tanggal DESC
		LIMIT $1
	`, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	result := []entity.RiwayatOperasional{}
	for rows.Next() {
		var tanggal, jamMulaiRencana, jamSelesaiRencana string
		var jamMulaiAktual, jamSelesaiAktual *time.Time
		if err := rows.Scan(&tanggal, &jamMulaiRencana, &jamSelesaiRencana, &jamMulaiAktual, &jamSelesaiAktual); err != nil {
			return nil, err
		}

		mulai := jamMulaiRencana
		if jamMulaiAktual != nil {
			mulai = jamMulaiAktual.Local().Format("15:04")
		}
		selesai := jamSelesaiRencana
		if jamSelesaiAktual != nil {
			selesai = jamSelesaiAktual.Local().Format("15:04")
		}

		durasiMenit := toMenit(selesai) - toMenit(mulai)
		if durasiMenit < 0 {
			durasiMenit = 0
		}

		status := "normal"
		switch {
		case toMenit(selesai) > toMenit(jamSelesaiRencana):
			status = "diperpanjang"
		case toMenit(selesai) < toMenit(jamSelesaiRencana):
			status = "diakhiri-awal"
		}

		result = append(result, entity.RiwayatOperasional{
			Tanggal:    formatTanggalID(tanggal),
			JamMulai:   mulai,
			JamSelesai: selesai,
			Durasi:     fmt.Sprintf("%dj %02dm", durasiMenit/60, durasiMenit%60),
			Status:     status,
		})
	}
	return result, rows.Err()
}

// GetJamOperasional -- dipanggil pas halaman dibuka.
func (r *PetugasRepository) GetJamOperasional(ctx context.Context) (*entity.JamOperasionalResponse, error) {
	sesi, err := r.getOrCreateSesiHariIni(ctx)
	if err != nil {
		return nil, err
	}
	riwayat, err := r.getRiwayatOperasional(ctx, 10)
	if err != nil {
		return nil, err
	}
	return &entity.JamOperasionalResponse{
		Sesi:    buildStatusSesi(sesi),
		Riwayat: riwayat,
	}, nil
}

// UpdateJamRencana -- tombol "Simpan Perubahan".
func (r *PetugasRepository) UpdateJamRencana(ctx context.Context, jamMulai, jamSelesai string) (*entity.JamOperasionalResponse, error) {
	// Cek apakah masih bisa edit (sebelum 23:59)
	if !r.canEditToday(ctx) {
		return nil, errors.New("tidak bisa mengubah jam operasional untuk hari ini, sudah melewati batas waktu (23:59)")
	}

	sesi, err := r.getOrCreateSesiHariIni(ctx)
	if err != nil {
		return nil, err
	}

	var updated *sesiRow

	// Update berdasarkan status
	switch sesi.Status {
	case "berlangsung":
		// Saat berlangsung, hanya update jam_selesai_rencana (perpanjang)
		updated, err = scanSesi(r.db.QueryRow(ctx,
			`UPDATE jam_operasional_sessions
			 SET jam_selesai_rencana = $2, updated_at = now()
			 WHERE id = $1 AND status = 'berlangsung'
			 RETURNING `+sesiColumns,
			sesi.ID, jamSelesai))
	case "belum_dimulai", "selesai":
		// Saat belum_dimulai ATAU selesai, update semua jam
		updated, err = scanSesi(r.db.QueryRow(ctx,
			`UPDATE jam_operasional_sessions
			 SET jam_mulai_rencana = $2, jam_selesai_rencana = $3, updated_at = now()
			 WHERE id = $1 AND status IN ('belum_dimulai', 'selesai')
			 RETURNING `+sesiColumns,
			sesi.ID, jamMulai, jamSelesai))
	default:
		return nil, fmt.Errorf("status sesi tidak dikenal: %s", sesi.Status)
	}

	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, fmt.Errorf("tidak bisa mengubah jam, status sesi saat ini: %s", sesi.Status)
		}
		return nil, err
	}

	riwayat, err := r.getRiwayatOperasional(ctx, 10)
	if err != nil {
		return nil, err
	}
	return &entity.JamOperasionalResponse{Sesi: buildStatusSesi(updated), Riwayat: riwayat}, nil
}

// MulaiSesiOperasional: belum_dimulai -> berlangsung.
// Bisa mulai dari status 'belum_dimulai' ATAU 'selesai'
func (r *PetugasRepository) MulaiSesiOperacional(ctx context.Context, petugasID string) (*entity.JamOperasionalResponse, error) {
	// Cek apakah masih bisa mulai sesi (belum lewat 23:59)
	if !r.canEditToday(ctx) {
		return nil, errors.New("tidak bisa memulai sesi, sudah melewati batas waktu (23:59)")
	}

	sesi, err := r.getOrCreateSesiHariIni(ctx)
	if err != nil {
		return nil, err
	}

	var updated *sesiRow

	// Bisa mulai dari 'belum_dimulai' ATAU 'selesai'
	switch sesi.Status {
	case "belum_dimulai":
		// Kasus normal: belum_dimulai -> berlangsung
		updated, err = scanSesi(r.db.QueryRow(ctx,
			`UPDATE jam_operasional_sessions
			 SET status = 'berlangsung', 
			     jam_mulai_aktual = now(), 
			     jam_selesai_aktual = NULL,
			     dibuka_oleh = $2, 
			     ditutup_oleh = NULL,
			     updated_at = now()
			 WHERE id = $1 AND status = 'belum_dimulai'
			 RETURNING `+sesiColumns,
			sesi.ID, petugasID))
	case "selesai":
		// Kasus restart: selesai -> berlangsung (reset semua)
		updated, err = scanSesi(r.db.QueryRow(ctx,
			`UPDATE jam_operasional_sessions
			 SET status = 'berlangsung', 
			     jam_mulai_aktual = now(), 
			     jam_selesai_aktual = NULL,
			     dibuka_oleh = $2, 
			     ditutup_oleh = NULL,
			     updated_at = now()
			 WHERE id = $1 AND status = 'selesai'
			 RETURNING `+sesiColumns,
			sesi.ID, petugasID))
	default:
		// Kalau status 'berlangsung', kasih error yang jelas
		return nil, fmt.Errorf("sesi sedang berlangsung, tidak bisa dimulai lagi")
	}

	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, errors.New("tidak bisa memulai sesi, status sesi tidak sesuai")
		}
		return nil, err
	}

	riwayat, err := r.getRiwayatOperasional(ctx, 10)
	if err != nil {
		return nil, err
	}
	return &entity.JamOperasionalResponse{Sesi: buildStatusSesi(updated), Riwayat: riwayat}, nil
}

// AkhiriSesiOperasional: berlangsung -> selesai.
func (r *PetugasRepository) AkhiriSesiOperasional(ctx context.Context, petugasID string) (*entity.JamOperasionalResponse, error) {
	// Cek apakah masih bisa akhiri sesi (belum lewat 23:59)
	if !r.canEditToday(ctx) {
		return nil, errors.New("tidak bisa mengakhiri sesi, sudah melewati batas waktu (23:59)")
	}

	sesi, err := r.getOrCreateSesiHariIni(ctx)
	if err != nil {
		return nil, err
	}

	updated, err := scanSesi(r.db.QueryRow(ctx,
		`UPDATE jam_operasional_sessions
		 SET status = 'selesai', jam_selesai_aktual = now(), ditutup_oleh = $2, updated_at = now()
		 WHERE id = $1 AND status = 'berlangsung'
		 RETURNING `+sesiColumns,
		sesi.ID, petugasID))
	if err != nil {
		return nil, err
	}

	riwayat, err := r.getRiwayatOperasional(ctx, 10)
	if err != nil {
		return nil, err
	}
	return &entity.JamOperasionalResponse{Sesi: buildStatusSesi(updated), Riwayat: riwayat}, nil
}

// ==================== VERIFIKASI PENGAJUAN ====================

func (r *PetugasRepository) GetDaftarPengajuan(ctx context.Context) ([]entity.PengajuanItem, error) {
	rows, err := r.db.Query(ctx, `
		SELECT 
			p.id,
			p.user_id,
			p.nama_usaha,
			p.jenis_dagangan,
			p.nik,
			p.alamat,
			p.status_verifikasi,
			TO_CHAR(p.created_at, 'DD Mon YYYY') as tanggal_ajuan
		FROM pedagang_profiles p
		WHERE p.deleted_at IS NULL
		  AND p.status_verifikasi IN ('pending', 'approved', 'rejected')
		ORDER BY p.created_at DESC
	`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	result := []entity.PengajuanItem{}
	for rows.Next() {
		var item entity.PengajuanItem
		err := rows.Scan(
			&item.ID,
			&item.UserID,
			&item.NamaUsaha,
			&item.JenisDagangan,
			&item.NIK,
			&item.Alamat,
			&item.Status,
			&item.TanggalAjuan,
		)
		if err != nil {
			return nil, err
		}
		result = append(result, item)
	}
	return result, nil
}

func (r *PetugasRepository) GetDetailPengajuan(ctx context.Context, pengajuanID string) (*entity.DetailPengajuanResponse, error) {
	var result entity.DetailPengajuanResponse
	var catatan *string

	err := r.db.QueryRow(ctx, `
		SELECT 
			p.id,
			p.user_id,
			p.nama_usaha,
			p.jenis_dagangan,
			p.nik,
			p.alamat,
			p.status_verifikasi,
			p.catatan,
			TO_CHAR(p.created_at, 'DD Mon YYYY') as tanggal_ajuan,
			u.name,
			u.email,
			u.phone
		FROM pedagang_profiles p
		JOIN users u ON u.id = p.user_id AND u.deleted_at IS NULL
		WHERE p.id = $1 AND p.deleted_at IS NULL
	`, pengajuanID).Scan(
		&result.ID,
		&result.UserID,
		&result.NamaUsaha,
		&result.JenisDagangan,
		&result.NIK,
		&result.Alamat,
		&result.Status,
		&catatan,
		&result.TanggalAjuan,
		&result.DataPemilik.Nama,
		&result.DataPemilik.Email,
		&result.DataPemilik.Phone,
	)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, nil
		}
		return nil, err
	}

	if catatan != nil {
		result.Catatan = *catatan
	}

	return &result, nil
}

func (r *PetugasRepository) VerifikasiPengajuan(ctx context.Context, pengajuanID, petugasID string, status, catatan string) error {
	tx, err := r.db.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)

	_, err = tx.Exec(ctx, `
		UPDATE pedagang_profiles 
		SET status_verifikasi = $1, 
		    catatan = $2, 
		    verified_by = $3, 
		    verified_at = NOW(),
		    updated_at = NOW()
		WHERE id = $4 AND deleted_at IS NULL
	`, status, catatan, petugasID, pengajuanID)
	if err != nil {
		return err
	}

	_, err = tx.Exec(ctx, `
		INSERT INTO pedagang_verifications (pedagang_id, status, catatan, verified_by)
		VALUES ($1, $2, $3, $4)
	`, pengajuanID, status, catatan, petugasID)
	if err != nil {
		return err
	}

	return tx.Commit(ctx)
}