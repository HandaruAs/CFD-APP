// modules/petugas/controller/petugas_controller.go

package controller

import (
	"errors"
	"net/http"
	"strconv"

	"cfd-backend/modules/petugas/entity"
	"cfd-backend/modules/petugas/usecase"

	"github.com/gin-gonic/gin"
)

type PetugasController struct {
	petugasUsecase usecase.PetugasUsecase
}

func NewPetugasController(petugasUsecase usecase.PetugasUsecase) *PetugasController {
	return &PetugasController{petugasUsecase: petugasUsecase}
}

// ==================== DASHBOARD ====================
func (ctrl *PetugasController) GetDashboard(c *gin.Context) {
	data, err := ctrl.petugasUsecase.GetDashboard(c.Request.Context())
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "gagal mengambil data dashboard: " + err.Error()})
		return
	}
	c.JSON(http.StatusOK, data)
}

// ==================== DATA PEDAGANG ====================
func (ctrl *PetugasController) GetListPedagang(c *gin.Context) {
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "10"))
	search := c.DefaultQuery("search", "")
	kategori := c.DefaultQuery("kategori", "")
	zona := c.DefaultQuery("zona", "")

	data, err := ctrl.petugasUsecase.GetListPedagang(c.Request.Context(), page, limit, search, kategori, zona)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "gagal mengambil data pedagang: " + err.Error()})
		return
	}
	c.JSON(http.StatusOK, data)
}

// ==================== MANAJEMEN LAPAK ====================
func (ctrl *PetugasController) GetManajemenLapak(c *gin.Context) {
	data, err := ctrl.petugasUsecase.GetManajemenLapak(c.Request.Context())
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "gagal mengambil data lapak: " + err.Error()})
		return
	}
	c.JSON(http.StatusOK, data)
}

// ==================== JAM OPERASIONAL ====================
func (ctrl *PetugasController) GetJamOperasional(c *gin.Context) {
	data, err := ctrl.petugasUsecase.GetJamOperasional(c.Request.Context())
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "gagal mengambil data jam operasional: " + err.Error()})
		return
	}
	c.JSON(http.StatusOK, data)
}

// UpdateJamOperasional -- tombol "Simpan Perubahan".
func (ctrl *PetugasController) UpdateJamOperasional(c *gin.Context) {
	var req entity.UpdateJamRencanaRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	if req.JamMulai == "" || req.JamSelesai == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "jam mulai dan jam selesai harus diisi"})
		return
	}

	data, err := ctrl.petugasUsecase.UpdateJamRencana(c.Request.Context(), &req)
	if err != nil {
		if errors.Is(err, usecase.ErrSesiSalahStatus) {
			c.JSON(http.StatusConflict, gin.H{"error": "tidak bisa mengubah jam, sesi sedang berlangsung. Hanya jam selesai yang bisa diubah."})
			return
		}
		if errors.Is(err, usecase.ErrBatasWaktuBerlalu) {
			c.JSON(http.StatusConflict, gin.H{"error": "tidak bisa mengubah jam operasional, sudah melewati batas waktu hari ini (23:59)"})
			return
		}
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, data)
}

// MulaiSesiOperasional -- tombol "Mulai Sesi".
func (ctrl *PetugasController) MulaiSesiOperasional(c *gin.Context) {
	petugasID, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "user tidak terautentikasi"})
		return
	}

	data, err := ctrl.petugasUsecase.MulaiSesiOperasional(c.Request.Context(), petugasID.(string))
	if err != nil {
		if errors.Is(err, usecase.ErrSesiSalahStatus) {
			c.JSON(http.StatusConflict, gin.H{"error": "tidak bisa memulai sesi, status sesi tidak sesuai"})
			return
		}
		if errors.Is(err, usecase.ErrBatasWaktuBerlalu) {
			c.JSON(http.StatusConflict, gin.H{"error": "tidak bisa memulai sesi, sudah melewati batas waktu hari ini (23:59)"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": "gagal memulai sesi: " + err.Error()})
		return
	}
	c.JSON(http.StatusOK, data)
}

// AkhiriSesiOperasional -- tombol "Akhiri Sesi Lebih Awal".
func (ctrl *PetugasController) AkhiriSesiOperasional(c *gin.Context) {
	petugasID, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "user tidak terautentikasi"})
		return
	}

	data, err := ctrl.petugasUsecase.AkhiriSesiOperasional(c.Request.Context(), petugasID.(string))
	if err != nil {
		if errors.Is(err, usecase.ErrSesiSalahStatus) {
			c.JSON(http.StatusConflict, gin.H{"error": "sesi belum berjalan, tidak bisa diakhiri"})
			return
		}
		if errors.Is(err, usecase.ErrBatasWaktuBerlalu) {
			c.JSON(http.StatusConflict, gin.H{"error": "tidak bisa mengakhiri sesi, sudah melewati batas waktu hari ini (23:59)"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": "gagal mengakhiri sesi: " + err.Error()})
		return
	}
	c.JSON(http.StatusOK, data)
}

// ==================== VERIFIKASI PENGAJUAN ====================
func (ctrl *PetugasController) GetDaftarPengajuan(c *gin.Context) {
	data, err := ctrl.petugasUsecase.GetDaftarPengajuan(c.Request.Context())
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "gagal mengambil daftar pengajuan: " + err.Error()})
		return
	}
	c.JSON(http.StatusOK, data)
}

func (ctrl *PetugasController) GetDetailPengajuan(c *gin.Context) {
	id := c.Param("id")
	if id == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "ID pengajuan diperlukan"})
		return
	}

	data, err := ctrl.petugasUsecase.GetDetailPengajuan(c.Request.Context(), id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "gagal mengambil detail pengajuan: " + err.Error()})
		return
	}
	if data == nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "pengajuan tidak ditemukan"})
		return
	}
	c.JSON(http.StatusOK, data)
}

func (ctrl *PetugasController) VerifikasiPengajuan(c *gin.Context) {
	id := c.Param("id")
	if id == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "ID pengajuan diperlukan"})
		return
	}

	var req entity.VerifikasiRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	petugasID, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "user tidak terautentikasi"})
		return
	}

	err := ctrl.petugasUsecase.VerifikasiPengajuan(
		c.Request.Context(),
		id,
		petugasID.(string),
		&req,
	)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "gagal verifikasi pengajuan: " + err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"message": "pengajuan berhasil diverifikasi",
		"id":      id,
		"status":  req.Status,
	})
}