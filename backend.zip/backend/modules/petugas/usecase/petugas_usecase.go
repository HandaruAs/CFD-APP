// modules/petugas/usecase/petugas_usecase.go

package usecase

import (
	"context"
	"errors"
	"fmt"
	"regexp"
	"strconv"
	"strings"

	"cfd-backend/modules/petugas/entity"

	"github.com/jackc/pgx/v5"
)

var (
	ErrSesiSalahStatus   = errors.New("aksi tidak valid untuk status sesi saat ini")
	ErrBatasWaktuBerlalu = errors.New("batas waktu edit hari ini sudah lewat (23:59)")
)

var jamPattern = regexp.MustCompile(`^([01]\d|2[0-3]):[0-5]\d$`)

type PetugasRepository interface {
	GetDashboard(ctx context.Context) (*entity.DashboardResponse, error)
	GetListPedagang(ctx context.Context, page, limit int, search, kategori, zona string) (*entity.ListPedagangResponse, error)
	GetManajemenLapak(ctx context.Context) (*entity.ManajemenLapakResponse, error)
	GetJamOperasional(ctx context.Context) (*entity.JamOperasionalResponse, error)
	UpdateJamRencana(ctx context.Context, jamMulai, jamSelesai string) (*entity.JamOperasionalResponse, error)
	MulaiSesiOperacional(ctx context.Context, petugasID string) (*entity.JamOperasionalResponse, error)
	AkhiriSesiOperasional(ctx context.Context, petugasID string) (*entity.JamOperasionalResponse, error)
	GetDaftarPengajuan(ctx context.Context) ([]entity.PengajuanItem, error)
	GetDetailPengajuan(ctx context.Context, pengajuanID string) (*entity.DetailPengajuanResponse, error)
	VerifikasiPengajuan(ctx context.Context, pengajuanID, petugasID string, status, catatan string) error
}

type PetugasUsecase interface {
	GetDashboard(ctx context.Context) (*entity.DashboardResponse, error)
	GetListPedagang(ctx context.Context, page, limit int, search, kategori, zona string) (*entity.ListPedagangResponse, error)
	GetManajemenLapak(ctx context.Context) (*entity.ManajemenLapakResponse, error)
	GetJamOperasional(ctx context.Context) (*entity.JamOperasionalResponse, error)
	UpdateJamRencana(ctx context.Context, req *entity.UpdateJamRencanaRequest) (*entity.JamOperasionalResponse, error)
	MulaiSesiOperasional(ctx context.Context, petugasID string) (*entity.JamOperasionalResponse, error)
	AkhiriSesiOperasional(ctx context.Context, petugasID string) (*entity.JamOperasionalResponse, error)
	GetDaftarPengajuan(ctx context.Context) ([]entity.PengajuanItem, error)
	GetDetailPengajuan(ctx context.Context, pengajuanID string) (*entity.DetailPengajuanResponse, error)
	VerifikasiPengajuan(ctx context.Context, pengajuanID, petugasID string, req *entity.VerifikasiRequest) error
}

type petugasUsecase struct {
	petugasRepo PetugasRepository
}

func NewPetugasUsecase(petugasRepo PetugasRepository) PetugasUsecase {
	return &petugasUsecase{petugasRepo: petugasRepo}
}

func (u *petugasUsecase) GetDashboard(ctx context.Context) (*entity.DashboardResponse, error) {
	return u.petugasRepo.GetDashboard(ctx)
}

func (u *petugasUsecase) GetListPedagang(ctx context.Context, page, limit int, search, kategori, zona string) (*entity.ListPedagangResponse, error) {
	if page < 1 {
		page = 1
	}
	if limit < 1 || limit > 100 {
		limit = 10
	}
	return u.petugasRepo.GetListPedagang(ctx, page, limit, search, kategori, zona)
}

func (u *petugasUsecase) GetManajemenLapak(ctx context.Context) (*entity.ManajemenLapakResponse, error) {
	return u.petugasRepo.GetManajemenLapak(ctx)
}

func (u *petugasUsecase) GetJamOperasional(ctx context.Context) (*entity.JamOperasionalResponse, error) {
	return u.petugasRepo.GetJamOperasional(ctx)
}

func (u *petugasUsecase) UpdateJamRencana(ctx context.Context, req *entity.UpdateJamRencanaRequest) (*entity.JamOperasionalResponse, error) {
	// Validasi format
	if !jamPattern.MatchString(req.JamMulai) || !jamPattern.MatchString(req.JamSelesai) {
		return nil, fmt.Errorf("format jam harus HH:MM")
	}

	// Validasi jam mulai < jam selesai
	mulaiParts := strings.Split(req.JamMulai, ":")
	selesaiParts := strings.Split(req.JamSelesai, ":")
	mulaiJam, _ := strconv.Atoi(mulaiParts[0])
	mulaiMenit, _ := strconv.Atoi(mulaiParts[1])
	selesaiJam, _ := strconv.Atoi(selesaiParts[0])
	selesaiMenit, _ := strconv.Atoi(selesaiParts[1])
	mulaiTotal := mulaiJam*60 + mulaiMenit
	selesaiTotal := selesaiJam*60 + selesaiMenit

	if mulaiTotal >= selesaiTotal {
		return nil, fmt.Errorf("jam mulai harus sebelum jam selesai")
	}

	data, err := u.petugasRepo.UpdateJamRencana(ctx, req.JamMulai, req.JamSelesai)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, ErrSesiSalahStatus
		}
		if strings.Contains(err.Error(), "batas waktu") {
			return nil, ErrBatasWaktuBerlalu
		}
		return nil, err
	}
	return data, nil
}

func (u *petugasUsecase) MulaiSesiOperasional(ctx context.Context, petugasID string) (*entity.JamOperasionalResponse, error) {
	data, err := u.petugasRepo.MulaiSesiOperacional(ctx, petugasID)
	if err != nil {
		if strings.Contains(err.Error(), "tidak bisa memulai sesi") {
			return nil, ErrSesiSalahStatus
		}
		if strings.Contains(err.Error(), "batas waktu") {
			return nil, ErrBatasWaktuBerlalu
		}
		if strings.Contains(err.Error(), "sedang berlangsung") {
			return nil, fmt.Errorf("sesi sedang berlangsung, akhiri sesi terlebih dahulu")
		}
		return nil, err
	}
	return data, nil
}

func (u *petugasUsecase) AkhiriSesiOperasional(ctx context.Context, petugasID string) (*entity.JamOperasionalResponse, error) {
	data, err := u.petugasRepo.AkhiriSesiOperasional(ctx, petugasID)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, ErrSesiSalahStatus
		}
		if strings.Contains(err.Error(), "batas waktu") {
			return nil, ErrBatasWaktuBerlalu
		}
		return nil, err
	}
	return data, nil
}

func (u *petugasUsecase) GetDaftarPengajuan(ctx context.Context) ([]entity.PengajuanItem, error) {
	return u.petugasRepo.GetDaftarPengajuan(ctx)
}

func (u *petugasUsecase) GetDetailPengajuan(ctx context.Context, pengajuanID string) (*entity.DetailPengajuanResponse, error) {
	return u.petugasRepo.GetDetailPengajuan(ctx, pengajuanID)
}

func (u *petugasUsecase) VerifikasiPengajuan(ctx context.Context, pengajuanID, petugasID string, req *entity.VerifikasiRequest) error {
	if req.Status != "approved" && req.Status != "rejected" {
		return fmt.Errorf("status harus 'approved' atau 'rejected'")
	}
	return u.petugasRepo.VerifikasiPengajuan(ctx, pengajuanID, petugasID, req.Status, req.Catatan)
}