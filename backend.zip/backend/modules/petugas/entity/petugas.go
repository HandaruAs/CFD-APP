// modules/petugas/entity/petugas.go

package entity

// ==================== DTO untuk Dashboard ====================

type DashboardResponse struct {
	StatusArea         string           `json:"statusArea"`
	JamMulai           string           `json:"jamMulai"`
	JamSelesai         string           `json:"jamSelesai"`
	TotalLapak         int              `json:"totalLapak"`
	LapakTerisi        int              `json:"lapakTerisi"`
	PersenTerisi       float64          `json:"persenTerisi"`
	PetugasAktif       int              `json:"petugasAktif"`
	KehadiranTerbaru   []KehadiranItem  `json:"kehadiranTerbaru"`
}

type UpdateJamRencanaRequest struct {
	JamMulai   string `json:"jamMulai" binding:"required"`
	JamSelesai string `json:"jamSelesai" binding:"required"`
}

type KehadiranItem struct {
	KodeLapak string `json:"kodeLapak"`
	Nama      string `json:"nama"`
	Kategori  string `json:"kategori"`
	Waktu     string `json:"waktu"`
}

// ==================== DTO untuk Data Pedagang ====================

type DataPedagangResponse struct {
	ID              string `json:"id"`
	NamaUsaha       string `json:"namaUsaha"`
	Pemilik         string `json:"pemilik"`
	Inisial         string `json:"inisial"`
	Kategori        string `json:"kategori"`
	LokasiLapak     string `json:"lokasiLapak"`
	StatusKehadiran string `json:"statusKehadiran"`
}

type ListPedagangResponse struct {
	Data       []DataPedagangResponse `json:"data"`
	Total      int                    `json:"total"`
	Page       int                    `json:"page"`
	Limit      int                    `json:"limit"`
	TotalPages int                    `json:"totalPages"`
}

// ==================== DTO untuk Manajemen Lapak ====================

type LapakItem struct {
	Kode     string  `json:"kode"`
	Status   string  `json:"status"`
	Pedagang *string `json:"pedagang,omitempty"`
}

type ZonaLapak struct {
	Nama  string      `json:"nama"`
	Label string      `json:"label"`
	Lapak []LapakItem `json:"lapak"`
}

type ManajemenLapakResponse struct {
	TotalLapak    int         `json:"totalLapak"`
	LapakTerisi   int         `json:"lapakTerisi"`
	LapakTersedia int         `json:"lapakTersedia"`
	Zona          []ZonaLapak `json:"zona"`
}

// ==================== DTO untuk Jam Operasional ====================

type StatusSesiResponse struct {
	Status     string `json:"status"`
	JamMulai   string `json:"jamMulai"`
	JamSelesai string `json:"jamSelesai"`
	SisaWaktu  string `json:"sisaWaktu"`
	TotalMenit int    `json:"totalMenit"`
	SisaMenit  int    `json:"sisaMenit"`
}

type RiwayatOperasional struct {
	Tanggal    string `json:"tanggal"`
	JamMulai   string `json:"jamMulai"`
	JamSelesai string `json:"jamSelesai"`
	Durasi     string `json:"durasi"`
	Status     string `json:"status"`
}

type JamOperasionalResponse struct {
	Sesi    StatusSesiResponse    `json:"sesi"`
	Riwayat []RiwayatOperasional  `json:"riwayat"`
}

// ==================== DTO untuk Verifikasi Pengajuan ====================

type PengajuanItem struct {
	ID            string `json:"id"`
	UserID        string `json:"userId"`
	NamaUsaha     string `json:"namaUsaha"`
	JenisDagangan string `json:"jenisDagangan"`
	NIK           string `json:"nik"`
	Alamat        string `json:"alamat"`
	Status        string `json:"status"`
	TanggalAjuan  string `json:"tanggalAjuan"`
}

type DetailPengajuanResponse struct {
	ID            string `json:"id"`
	UserID        string `json:"userId"`
	NamaUsaha     string `json:"namaUsaha"`
	JenisDagangan string `json:"jenisDagangan"`
	NIK           string `json:"nik"`
	Alamat        string `json:"alamat"`
	Status        string `json:"status"`
	Catatan       string `json:"catatan"`
	TanggalAjuan  string `json:"tanggalAjuan"`
	DataPemilik   struct {
		Nama  string `json:"nama"`
		Email string `json:"email"`
		Phone string `json:"phone"`
	} `json:"dataPemilik"`
}

type VerifikasiRequest struct {
	Status  string `json:"status" binding:"required,oneof=approved rejected"`
	Catatan string `json:"catatan"`
}