package usecase

import (
	"context"

	"cfd-backend/modules/pedagang/entity"
)

type PedagangRepository interface {
	CreatePengajuan(ctx context.Context, userID, nik, namaUsaha, jenisDagangan, alamat string) (string, error)
	GetPengajuanByUserID(ctx context.Context, userID string) (*entity.PengajuanStatus, error)
	ListPedagang(ctx context.Context) ([]entity.PedagangUserDTO, int, error) 
}

type PedagangUsecase interface {
	AjukanUsaha(ctx context.Context, userID string, req *entity.PengajuanUsahaRequest) (string, error)
	StatusPengajuan(ctx context.Context, userID string) (*entity.PengajuanStatus, error)
	CreatePengajuanByAdmin(ctx context.Context, userID, nik, namaUsaha, jenisDagangan, alamat string) error
	ListPedagangByAdmin(ctx context.Context) ([]entity.PedagangUserDTO, int, error)
}

type pedagangUsecase struct {
	pedagangRepo PedagangRepository
}

func NewPedagangUsecase(pedagangRepo PedagangRepository) PedagangUsecase {
	return &pedagangUsecase{pedagangRepo: pedagangRepo}
}

func (u *pedagangUsecase) AjukanUsaha(ctx context.Context, userID string, req *entity.PengajuanUsahaRequest) (string, error) {
	return u.pedagangRepo.CreatePengajuan(ctx, userID, req.NIK, req.NamaUsaha, req.JenisDagangan, req.Alamat)
}

func (u *pedagangUsecase) StatusPengajuan(ctx context.Context, userID string) (*entity.PengajuanStatus, error) {
	return u.pedagangRepo.GetPengajuanByUserID(ctx, userID)
}

func (u *pedagangUsecase) CreatePengajuanByAdmin(ctx context.Context, userID, nik, namaUsaha, jenisDagangan, alamat string) error {
	_, err := u.pedagangRepo.CreatePengajuan(ctx, userID, nik, namaUsaha, jenisDagangan, alamat)
	return err
}

// --- NEW METHOD ---
func (u *pedagangUsecase) ListPedagangByAdmin(ctx context.Context) ([]controller.PedagangUserDTO, int, error) {
	return u.pedagangRepo.ListPedagang(ctx)
}