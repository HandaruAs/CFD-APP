package usecase

import (
	"context"
	"time"

	"cfd-backend/modules/pedagang/lapak/entity"
)

type LapakRepository interface {
	GetOrCreateSessionHariIni(ctx context.Context) (string, error)
	GetPedagangProfileIDByUserID(ctx context.Context, userID string) (string, error)
	ListKecamatan(ctx context.Context) ([]entity.KecamatanDTO, error)
	ListJalanByKecamatan(ctx context.Context, kecamatanID, sessionID string) ([]entity.JalanDTO, error)
	ClaimSlot(ctx context.Context, pedagangID, sessionID string) (nomorLapak, namaJalan, namaKecamatan string, claimedAt time.Time, err error)
	GetKlaimByPedagangSession(ctx context.Context, pedagangID, sessionID string) (nomorLapak, namaJalan, namaKecamatan string, claimedAt time.Time, found bool, err error)
	GetNamaRuasKlaim(ctx context.Context, pedagangID, sessionID string) (string, error)
}

type LapakUsecase interface {
	ListKecamatan(ctx context.Context) ([]entity.KecamatanDTO, error)
	ListJalan(ctx context.Context, kecamatanID string) ([]entity.JalanDTO, error)
	ClaimLapak(ctx context.Context, userID string) (*entity.ClaimLapakResponse, error)
	GetStatus(ctx context.Context, userID string) (*entity.StatusLapakResponse, error)
}

type lapakUsecase struct {
	repo LapakRepository
}

func NewLapakUsecase(repo LapakRepository) LapakUsecase {
	return &lapakUsecase{repo: repo}
}

func (u *lapakUsecase) ListKecamatan(ctx context.Context) ([]entity.KecamatanDTO, error) {
	return u.repo.ListKecamatan(ctx)
}

func (u *lapakUsecase) ListJalan(ctx context.Context, kecamatanID string) ([]entity.JalanDTO, error) {
	sessionID, err := u.repo.GetOrCreateSessionHariIni(ctx)
	if err != nil {
		return nil, err
	}
	return u.repo.ListJalanByKecamatan(ctx, kecamatanID, sessionID)
}

func (u *lapakUsecase) ClaimLapak(ctx context.Context, userID string) (*entity.ClaimLapakResponse, error) {
	sessionID, err := u.repo.GetOrCreateSessionHariIni(ctx)
	if err != nil {
		return nil, err
	}

	pedagangID, err := u.repo.GetPedagangProfileIDByUserID(ctx, userID)
	if err != nil {
		return nil, err
	}

	nomorLapak, namaJalan, namaKecamatan, claimedAt, err := u.repo.ClaimSlot(ctx, pedagangID, sessionID)
	if err != nil {
		return nil, err
	}

	// Nama ruas cuma pelengkap tampilan -- klaimnya sudah tersimpan, jadi
	// gagal ambil nama ruas bukan alasan buat nge-gagalin respon klaim.
	namaRuas, _ := u.repo.GetNamaRuasKlaim(ctx, pedagangID, sessionID)

	return &entity.ClaimLapakResponse{
		NomorLapak:    nomorLapak,
		NamaJalan:     namaJalan,
		NamaKecamatan: namaKecamatan,
		NamaRuas:      namaRuas,
		ClaimedAt:     claimedAt,
	}, nil
}

// GetStatus dipakai frontend buat 2 hal sekaligus: (1) nentuin apakah form
// klaim boleh ditampilin sama sekali (SesiAktif), dan (2) kalau boleh,
// apakah pedagang ini udah pernah klaim (SudahKlaim).
//
// SesiAktif sekarang SELALU true -- pedagang boleh klaim kapan aja gak
// peduli petugas udah buka sesi manual atau belum (lihat komentar di
// GetOrCreateSessionHariIni). Field ini dipertahankan (bukan dihapus) biar
// kontrak response ke frontend gak berubah; PesanSesi juga gak akan pernah
// keisi lagi dari jalur ini.
func (u *lapakUsecase) GetStatus(ctx context.Context, userID string) (*entity.StatusLapakResponse, error) {
	sessionID, err := u.repo.GetOrCreateSessionHariIni(ctx)
	if err != nil {
		return nil, err
	}

	pedagangID, err := u.repo.GetPedagangProfileIDByUserID(ctx, userID)
	if err != nil {
		return nil, err
	}

	nomorLapak, namaJalan, namaKecamatan, claimedAt, found, err := u.repo.GetKlaimByPedagangSession(ctx, pedagangID, sessionID)
	if err != nil {
		return nil, err
	}

	if !found {
		return &entity.StatusLapakResponse{SudahKlaim: false, SesiAktif: true}, nil
	}

	var namaRuasPtr *string
	if namaRuas, errRuas := u.repo.GetNamaRuasKlaim(ctx, pedagangID, sessionID); errRuas == nil && namaRuas != "" {
		namaRuasPtr = &namaRuas
	}

	return &entity.StatusLapakResponse{
		SudahKlaim:    true,
		SesiAktif:     true,
		NomorLapak:    &nomorLapak,
		NamaJalan:     &namaJalan,
		NamaKecamatan: &namaKecamatan,
		NamaRuas:      namaRuasPtr,
		ClaimedAt:     &claimedAt,
	}, nil
}