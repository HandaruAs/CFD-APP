package main

import (
	"log"
	"net/http"

	"cfd-backend/config"
	"cfd-backend/database"
	"cfd-backend/middleware"

	// Modul Repository
	menuRepo "cfd-backend/modules/menu/repository"
	pedagangRepo "cfd-backend/modules/pedagang/repository"
	petugasRepo "cfd-backend/modules/petugas/repository"
	permRepo "cfd-backend/modules/user/repository"
	userRepo "cfd-backend/modules/user/repository"

	// Modul Usecase
	authUsecase "cfd-backend/modules/auth/usecase"
	menuUsecase "cfd-backend/modules/menu/usecase"
	pedagangUsecase "cfd-backend/modules/pedagang/usecase"
	petugasUsecase "cfd-backend/modules/petugas/usecase"
	userUsecase "cfd-backend/modules/user/usecase"

	// Modul Controller
	authController "cfd-backend/modules/auth/controller"
	menuController "cfd-backend/modules/menu/controller"
	pedagangController "cfd-backend/modules/pedagang/controller"
	petugasController "cfd-backend/modules/petugas/controller"
	userController "cfd-backend/modules/user/controller"

	"github.com/gin-gonic/gin"
)

func main() {
	cfg := config.Load()

	db := database.Connect(cfg.DatabaseURL)
	defer db.Close()

	// 1. Init All Repositories
	userRepository := userRepo.NewUserRepository(db)
	pedagangRepository := pedagangRepo.NewPedagangRepository(db)
	menuRepository := menuRepo.NewMenuRepository(db)
	permissionRepository := permRepo.NewPermissionRepository(db)
	petugasRepository := petugasRepo.NewPetugasRepository(db)

	// 2. Init All Usecases
	authUsecase := authUsecase.NewAuthUsecase(userRepository, cfg.JWTSecret)
	userUsecase := userUsecase.NewUserUsecase(userRepository)
	pedagangUsecase := pedagangUsecase.NewPedagangUsecase(pedagangRepository)
	menuUsecase := menuUsecase.NewMenuUsecase(menuRepository, userRepository, pedagangRepository)
	petugasUsecase := petugasUsecase.NewPetugasUsecase(petugasRepository)

	// 3. Init All Controllers
	authController := authController.NewAuthController(authUsecase)
	userController := userController.NewUserController(userUsecase)
	pedagangController := pedagangController.NewPedagangController(pedagangUsecase, userUsecase)
	menuController := menuController.NewMenuController(menuUsecase)
	petugasController := petugasController.NewPetugasController(petugasUsecase)

	router := gin.Default()
	router.Use(middleware.CORSMiddleware(cfg.CORSAllowedOrigins))

	// Health check
	router.GET("/health", func(c *gin.Context) {
		c.JSON(200, gin.H{"status": "ok"})
	})

	// ============ ENDPOINT PUBLIK (TIDAK PERLU LOGIN) ============
	router.POST("/api/register", authController.RegisterPedagang)
	router.POST("/api/login", authController.Login)

	// ============ ENDPOINT PROTECTED (BUTUH LOGIN) ============
	router.GET("/api/me", middleware.AuthMiddleware(cfg.JWTSecret), userController.Me)
	router.GET("/api/menus", middleware.AuthMiddleware(cfg.JWTSecret), menuController.GetMyMenus)

	// ============ ENDPOINT KHUSUS ROLE ============

	// 1. Endpoint untuk PEDAGANG saja
	router.GET("/api/pedagang/dashboard",
		middleware.AuthMiddleware(cfg.JWTSecret),
		middleware.RoleMiddleware(userRepository, "pedagang"),
		func(c *gin.Context) {
			userID, _ := c.Get("user_id")
			c.JSON(http.StatusOK, gin.H{
				"message": "Selamat datang di Dashboard Pedagang!",
				"user_id": userID,
			})
		},
	)

	// 3. Endpoint untuk SUPERADMIN saja
	router.GET("/api/admin/dashboard",
		middleware.AuthMiddleware(cfg.JWTSecret),
		middleware.RoleMiddleware(userRepository, "superadmin"),
		func(c *gin.Context) {
			userID, _ := c.Get("user_id")
			c.JSON(http.StatusOK, gin.H{
				"message": "Selamat datang di Dashboard Super Admin!",
				"user_id": userID,
			})
		},
	)

	// 4. Endpoint untuk SUPERADMIN DAN PETUGAS_CFD (multi-role)
	router.GET("/api/verifikasi/pengajuan",
		middleware.AuthMiddleware(cfg.JWTSecret),
		middleware.RoleMiddleware(userRepository, "superadmin", "petugas"),
		func(c *gin.Context) {
			c.JSON(http.StatusOK, gin.H{
				"message": "Halaman verifikasi pengajuan (Superadmin & Petugas CFD)",
			})
		},
	)

	// 5. Contoh endpoint yang butuh login DAN permission spesifik
	router.GET("/api/admin/check",
		middleware.AuthMiddleware(cfg.JWTSecret),
		middleware.PermissionMiddleware(permissionRepository, "users.read"),
		func(c *gin.Context) {
			c.JSON(http.StatusOK, gin.H{"message": "kamu punya akses users.read"})
		},
	)

	// ============ ENDPOINT PEDAGANG ============
	router.POST("/api/pedagang/pengajuan",
		middleware.AuthMiddleware(cfg.JWTSecret),
		middleware.RoleMiddleware(userRepository, "pedagang"),
		pedagangController.AjukanUsaha,
	)

	router.GET("/api/pedagang/pengajuan",
		middleware.AuthMiddleware(cfg.JWTSecret),
		middleware.RoleMiddleware(userRepository, "pedagang"),
		pedagangController.StatusPengajuan,
	)

	// ============ ENDPOINT SUPERADMIN (Manajemen Pedagang) ============
	router.POST("/api/admin/users/pedagang",
		middleware.AuthMiddleware(cfg.JWTSecret),
		middleware.RoleMiddleware(userRepository, "superadmin"),
		pedagangController.CreatePedagangByAdmin,
	)

	router.GET("/api/admin/users/pedagang",
		middleware.AuthMiddleware(cfg.JWTSecret),
		middleware.RoleMiddleware(userRepository, "superadmin"),
		pedagangController.ListPedagangByAdmin,
	)

	router.GET("/api/admin/users/pedagang/stats",
		middleware.AuthMiddleware(cfg.JWTSecret),
		middleware.RoleMiddleware(userRepository, "superadmin"),
		pedagangController.GetPedagangStats,
	)

	router.GET("/api/admin/users/pedagang/:id",
		middleware.AuthMiddleware(cfg.JWTSecret),
		middleware.RoleMiddleware(userRepository, "superadmin"),
		pedagangController.GetPedagangByID,
	)

	router.DELETE("/api/admin/users/pedagang/:id",
		middleware.AuthMiddleware(cfg.JWTSecret),
		middleware.RoleMiddleware(userRepository, "superadmin"),
		pedagangController.DeletePedagangByAdmin,
	)

	// Dashboard Petugas
	router.GET("/api/petugas/dashboard",
		middleware.AuthMiddleware(cfg.JWTSecret),
		middleware.RoleMiddleware(userRepository, "petugas", "superadmin"),
		petugasController.GetDashboard,
	)

	// Data Pedagang
	router.GET("/api/petugas/pedagang",
		middleware.AuthMiddleware(cfg.JWTSecret),
		middleware.RoleMiddleware(userRepository, "petugas", "superadmin"),
		petugasController.GetListPedagang,
	)

	// Manajemen Lapak
	router.GET("/api/petugas/lapak",
		middleware.AuthMiddleware(cfg.JWTSecret),
		middleware.RoleMiddleware(userRepository, "petugas", "superadmin"),
		petugasController.GetManajemenLapak,
	)

	// Jam Operasional
	router.GET("/api/petugas/jam-operasional",
		middleware.AuthMiddleware(cfg.JWTSecret),
		middleware.RoleMiddleware(userRepository, "petugas", "superadmin"),
		petugasController.GetJamOperasional,
	)

	router.PUT("/api/petugas/jam-operasional",
		middleware.AuthMiddleware(cfg.JWTSecret),
		middleware.RoleMiddleware(userRepository, "petugas", "superadmin"),
		petugasController.UpdateJamOperasional,
	)
 
	router.POST("/api/petugas/jam-operasional/mulai",
		middleware.AuthMiddleware(cfg.JWTSecret),
		middleware.RoleMiddleware(userRepository, "petugas", "superadmin"),
		petugasController.MulaiSesiOperasional,
	)
 
	router.POST("/api/petugas/jam-operasional/akhiri",
		middleware.AuthMiddleware(cfg.JWTSecret),
		middleware.RoleMiddleware(userRepository, "petugas", "superadmin"),
		petugasController.AkhiriSesiOperasional,
	)
	
	// Verifikasi Pengajuan
	router.GET("/api/petugas/pengajuan",
		middleware.AuthMiddleware(cfg.JWTSecret),
		middleware.RoleMiddleware(userRepository, "petugas", "superadmin"),
		petugasController.GetDaftarPengajuan,
	)

	router.GET("/api/petugas/pengajuan/:id",
		middleware.AuthMiddleware(cfg.JWTSecret),
		middleware.RoleMiddleware(userRepository, "petugas", "superadmin"),
		petugasController.GetDetailPengajuan,
	)

	router.PUT("/api/petugas/pengajuan/:id/verifikasi",
		middleware.AuthMiddleware(cfg.JWTSecret),
		middleware.RoleMiddleware(userRepository, "petugas", "superadmin"),
		petugasController.VerifikasiPengajuan,
	)

	log.Printf("server jalan di port %s", cfg.Port)
	if err := router.Run(":" + cfg.Port); err != nil {
		log.Fatalf("server gagal jalan: %v", err)
	}
}
